package com.example.tarea3

interface Entrenar {
    fun correr() {
        println("Voy a correr.")
    }
    fun caminar() {
        println("Arranco a caminar.")
    }
    fun nadar() {
        println("A darse un chapuzón.")
    }
}