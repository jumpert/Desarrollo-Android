package com.example.tarea3

enum class Categoria {
    ADULTO,
    JOVEN,
    JUBILADO
}