package com.example.tarea3

// Video con nombre, duracion y tipo, el tipo es un enum de TipoVideo
class Video(nombre: String, duracion: Int, tipo: TipoVideo)

